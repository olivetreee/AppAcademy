require 'test_helper'

class CatsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
