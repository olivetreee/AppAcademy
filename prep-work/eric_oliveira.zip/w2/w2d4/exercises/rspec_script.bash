clear
rspec spec/board_spec.rb
rspec spec/human_player_spec.rb
rspec spec/computer_player_spec.rb
rspec spec/game_spec.rb
rspec spec
