clear
rspec spec/board_spec.rb
rspec spec/battleship_spec.rb
