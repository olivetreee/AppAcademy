def hello
  "Hello!"
end

def greet(person)
  "Hello, #{person}!"
end
