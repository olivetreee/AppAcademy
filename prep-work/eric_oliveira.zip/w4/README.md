# Week 4: Resume and JavaScript

### Resume Writing: [Prepare your Resume][resume]
- **NOTE**: If you've been conditionally accepted, this project is not yet required
- Make sure you complete this and send it to us before your first day!

### Solo Project: [Learn JavaScript][codecademy]
- Introduction to JavaScript through Codecademy
- Covers syntax, functions, loops, control flow, and data structures
- This shouldn't take more then 10 hour to complete

[resume]: resume/README.md
[codecademy]: https://www.codecademy.com/learn/javascript
